import TransactionTable from "@/components/Table/TransactionTable";

export default function Page(){
    return(
        <>
            <TransactionTable />
        </>
    )
}