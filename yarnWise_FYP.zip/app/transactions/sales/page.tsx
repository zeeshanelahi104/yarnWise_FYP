import SalesTable from "@/components/components/Sales/SalesTable";

export default function Page(){
    return(
        <div className="flex">
            <SalesTable />
        </div>
    )
}