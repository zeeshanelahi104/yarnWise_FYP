"use client";
import { Button } from "@/components/ui/button";
export default function UpdateUserBtn() {
  return (
    <div>
      <div className="register-field-btn  flex justify-center items-center py-8">
        <Button className=" bg-primary-clr primaryBtn w-[150px]">
          Update User
        </Button>
      </div>
    </div>
  );
}
